import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { sql } from "@/lib/db";

export async function GET() {
  try {
    const user = await getCurrentUser();
    if (!user || user.role !== "supervisor") {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const evaluations = await sql`
      SELECT 
        e.id,
        e.agent_id,
        u.name as agent_name,
        e.call_id,
        e.evaluator_type,
        e.total_score,
        e.category_scores,
        e.strengths,
        e.improvements,
        e.sop_violations,
        e.created_at
      FROM evaluations e
      JOIN users u ON e.agent_id = u.id
      WHERE u.team_id = ${user.team_id}
      ORDER BY e.created_at DESC
      LIMIT 50
    `;

    return NextResponse.json({ evaluations });
  } catch (error) {
    console.error("Error fetching evaluations:", error);
    return NextResponse.json(
      { error: "Failed to fetch evaluations" },
      { status: 500 }
    );
  }
}
