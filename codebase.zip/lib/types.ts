export type UserRole = "agent" | "supervisor" | "admin";

export interface User {
  id: string;
  email: string;
  name: string;
  role: UserRole;
  team_id: string | null;
  avatar_url: string | null;
  created_at: string;
  updated_at: string;
}

export interface SOP {
  id: string;
  title: string;
  content: string;
  category: string;
  version: number;
  created_by: string;
  created_at: string;
  updated_at: string;
}

export interface Call {
  id: string;
  agent_id: string;
  customer_phone: string;
  duration_seconds: number;
  call_type: "inbound" | "outbound";
  status: "completed" | "dropped" | "transferred";
  recording_url: string | null;
  created_at: string;
}

export interface Transcript {
  id: string;
  call_id: string;
  content: string;
  speaker_labels: Record<string, string>;
  sentiment_scores: Record<string, number>;
  created_at: string;
}

export interface Evaluation {
  id: string;
  call_id: string;
  agent_id: string;
  evaluator_type: "ai" | "human";
  evaluator_id: string | null;
  total_score: number;
  category_scores: Record<string, number>;
  strengths: string[];
  improvements: string[];
  sop_violations: string[];
  created_at: string;
}

export interface CoachingInsight {
  id: string;
  agent_id: string;
  evaluation_id: string | null;
  insight_type: "strength" | "improvement" | "trend";
  title: string;
  description: string;
  priority: "low" | "medium" | "high";
  acknowledged_at: string | null;
  created_at: string;
}

export interface Alert {
  id: string;
  user_id: string;
  alert_type: "score_drop" | "sop_violation" | "coaching_required" | "system";
  title: string;
  message: string;
  severity: "info" | "warning" | "critical";
  read_at: string | null;
  created_at: string;
}

export interface ScoringConfig {
  id: string;
  name: string;
  categories: ScoringCategory[];
  is_active: boolean;
  created_by: string;
  created_at: string;
  updated_at: string;
}

export interface ScoringCategory {
  name: string;
  weight: number;
  criteria: string[];
}

export interface DashboardStats {
  totalCalls: number;
  averageScore: number;
  scoreChange: number;
  coachingInsights: number;
  topPerformers: { name: string; score: number }[];
  recentEvaluations: Evaluation[];
}

export interface AgentPerformance {
  agentId: string;
  agentName: string;
  totalCalls: number;
  averageScore: number;
  trend: "up" | "down" | "stable";
  categoryScores: Record<string, number>;
}
